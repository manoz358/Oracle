#! /usr/bin/env python
import traceback, os
import json
import requests
#import jproperties
#import configparser
import json
#from jproperties import Properties
from requests.auth import HTTPBasicAuth
import sys

def FindDBLatestFile(fileList):
    print('OIC-->',fileList)
    try:
        fileList = fileList[:len(fileList) - 1]
        f=fileList.split(',')
        f.sort()
        print(f)
        print(f[-1])
        with open(f[-1], 'r') as firstfile, open('dbc/dbObj/controllerFinal.xml', 'w') as secondfile:
            for line in firstfile:
                secondfile.write(line)
    except Exception as e:
        print(e)
    finally:
        return 'File Copy Successful'
        
if __name__ == '__main__':
    FindDBLatestFile(sys.argv[1])
